#ifndef RELASI2_H_INCLUDED
#define RELASI2_H_INCLUDED

#include "Jadwal2.h"
#include "Pasien2.h"

void Koneksi(Jadwal* &P, Pasien* &C);

void disconnect(Pasien* &C);

void printRelasiChild(List_Pasien LC, Pasien* C, string tanggal);

void printRelasiChildTanggal(List_Pasien LC, Pasien* C);

void editKoneksi(Jadwal* &P, Pasien* &C);

void deleteParent(List_Jadwal &LP, Jadwal* P);

void findDelete(List_Jadwal &LP, List_Pasien &LC, Jadwal* &P);

#endif // RELASI2_H_INCLUDED
